import { Bell } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel,
  DropdownMenuTrigger, DropdownMenuSeparator,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "@tanstack/react-router";

interface Low { id: string; name: string; stock_quantity: number; low_stock_threshold: number; }

export function LowStockBell() {
  const [items, setItems] = useState<Low[]>([]);
  useEffect(() => {
    const load = async () => {
      const { data } = await supabase.from("products").select("id,name,stock_quantity,low_stock_threshold").limit(200);
      setItems((data ?? []).filter(p => p.stock_quantity <= p.low_stock_threshold));
    };
    load();
    const ch = supabase.channel("products-low-stock")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, []);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Notifications" className="relative">
          <Bell className="h-5 w-5" />
          {items.length > 0 && (
            <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-destructive px-1 text-[10px] font-semibold text-destructive-foreground">
              {items.length}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel>Low stock alerts</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {items.length === 0 && <div className="px-3 py-6 text-center text-sm text-muted-foreground">All stock healthy.</div>}
        {items.slice(0, 8).map(i => (
          <DropdownMenuItem key={i.id} asChild>
            <Link to="/products" className="flex items-center justify-between">
              <span className="truncate">{i.name}</span>
              <Badge variant="destructive">{i.stock_quantity}</Badge>
            </Link>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
