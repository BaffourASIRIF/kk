import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { Package, AlertTriangle, ShoppingCart, DollarSign, TrendingUp } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer,
  BarChart, Bar, CartesianGrid,
} from "recharts";

export const Route = createFileRoute("/_app/dashboard")({ component: Dashboard });

function Dashboard() {
  const q = useQuery({
    queryKey: ["dashboard"],
    queryFn: async () => {
      const [{ data: products }, { data: sales }, { data: tx }] = await Promise.all([
        supabase.from("products").select("id,name,stock_quantity,low_stock_threshold,selling_price"),
        supabase.from("sales").select("id,total_amount,created_at").order("created_at", { ascending: false }).limit(500),
        supabase.from("inventory_transactions").select("type,quantity,created_at").order("created_at", { ascending: false }).limit(500),
      ]);
      return { products: products ?? [], sales: sales ?? [], tx: tx ?? [] };
    },
  });

  useEffect(() => {
    const ch = supabase.channel("dash-products")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, () => q.refetch())
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [q]);

  const products = q.data?.products ?? [];
  const sales = q.data?.sales ?? [];
  const lowStock = products.filter(p => p.stock_quantity <= p.low_stock_threshold).length;
  const totalStockValue = products.reduce((a, p) => a + (Number(p.selling_price) * p.stock_quantity), 0);
  const totalSales = sales.reduce((a, s) => a + Number(s.total_amount), 0);

  // 7-day sales chart
  const days = Array.from({ length: 7 }).map((_, i) => {
    const d = new Date(); d.setDate(d.getDate() - (6 - i));
    const key = d.toISOString().slice(0, 10);
    const total = sales.filter(s => s.created_at.slice(0, 10) === key).reduce((a, s) => a + Number(s.total_amount), 0);
    return { day: d.toLocaleDateString(undefined, { weekday: "short" }), total };
  });

  const topProducts = [...products].sort((a, b) => b.stock_quantity - a.stock_quantity).slice(0, 5);

  const stats = [
    { icon: Package, label: "Products", value: products.length },
    { icon: AlertTriangle, label: "Low stock", value: lowStock, accent: lowStock > 0 ? "text-destructive" : "" },
    { icon: ShoppingCart, label: "Total sales", value: sales.length },
    { icon: DollarSign, label: "Stock value", value: `$${totalStockValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}` },
  ];

  return (
    <div>
      <PageHeader title="Dashboard" description="Realtime overview of inventory and operations." />
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map(s => (
          <Card key={s.label} className="p-5">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">{s.label}</span>
              <s.icon className={`h-4 w-4 text-muted-foreground ${s.accent ?? ""}`} />
            </div>
            <p className={`mt-3 font-display text-3xl font-semibold ${s.accent ?? ""}`}>{s.value}</p>
          </Card>
        ))}
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <Card className="p-5 lg:col-span-2">
          <div className="mb-4 flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
            <h3 className="font-display text-base font-semibold">Sales — last 7 days</h3>
            <span className="ml-auto text-sm text-muted-foreground">${totalSales.toLocaleString(undefined, { maximumFractionDigits: 0 })} total</span>
          </div>
          <div className="h-64">
            <ResponsiveContainer>
              <LineChart data={days}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="day" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis stroke="var(--muted-foreground)" fontSize={12} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Line type="monotone" dataKey="total" stroke="var(--primary)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </Card>

        <Card className="p-5">
          <h3 className="mb-4 font-display text-base font-semibold">Top stocked</h3>
          <div className="h-64">
            <ResponsiveContainer>
              <BarChart data={topProducts} layout="vertical">
                <XAxis type="number" stroke="var(--muted-foreground)" fontSize={12} />
                <YAxis dataKey="name" type="category" stroke="var(--muted-foreground)" fontSize={12} width={80} />
                <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
                <Bar dataKey="stock_quantity" fill="var(--primary)" radius={[0, 6, 6, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Card>
      </div>
    </div>
  );
}
