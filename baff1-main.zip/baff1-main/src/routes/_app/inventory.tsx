import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { ArrowLeftRight, Plus } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/inventory")({ component: InventoryPage });

function InventoryPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [productId, setProductId] = useState<string>("");
  const [type, setType] = useState<"stock_in" | "stock_out" | "adjustment">("stock_in");
  const [quantity, setQuantity] = useState(0);
  const [note, setNote] = useState("");

  const { data: tx = [] } = useQuery({
    queryKey: ["inv-tx"],
    queryFn: async () => (await supabase.from("inventory_transactions").select("*, products(name)").order("created_at", { ascending: false }).limit(200)).data ?? [],
  });
  const { data: products = [] } = useQuery({
    queryKey: ["products-min"],
    queryFn: async () => (await supabase.from("products").select("id,name,stock_quantity")).data ?? [],
  });

  useEffect(() => {
    const ch = supabase.channel("inv-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "inventory_transactions" }, () => qc.invalidateQueries({ queryKey: ["inv-tx"] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  async function record() {
    if (!productId || !quantity) { toast.error("Product and quantity required"); return; }
    const prod = (products as any[]).find(p => p.id === productId);
    if (!prod) return;
    const delta = type === "stock_in" ? quantity : type === "stock_out" ? -Math.abs(quantity) : quantity;
    const newQty = Math.max(0, prod.stock_quantity + delta);

    const { error: txErr } = await supabase.from("inventory_transactions").insert({
      product_id: productId, type, quantity: Math.abs(quantity), note: note || null, user_id: user!.id,
    });
    if (txErr) { toast.error(txErr.message); return; }
    const { error: upErr } = await supabase.from("products").update({ stock_quantity: newQty }).eq("id", productId);
    if (upErr) toast.error(upErr.message);
    else {
      toast.success("Recorded");
      setOpen(false); setProductId(""); setQuantity(0); setNote("");
      qc.invalidateQueries({ queryKey: ["products"] });
      qc.invalidateQueries({ queryKey: ["products-min"] });
    }
  }

  return (
    <div>
      <PageHeader title="Inventory" description="Stock in, stock out and adjustments — fully logged." actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New transaction</Button></DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle>Record stock movement</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2"><Label>Product</Label>
                <Select value={productId} onValueChange={setProductId}>
                  <SelectTrigger><SelectValue placeholder="Select product" /></SelectTrigger>
                  <SelectContent>{(products as any[]).map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.stock_quantity})</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Type</Label>
                <Select value={type} onValueChange={(v) => setType(v as any)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="stock_in">Stock in</SelectItem>
                    <SelectItem value="stock_out">Stock out</SelectItem>
                    <SelectItem value="adjustment">Adjustment (+/-)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2"><Label>Quantity</Label><Input type="number" value={quantity} onChange={e => setQuantity(Number(e.target.value))} /></div>
              <div className="space-y-2"><Label>Note</Label><Textarea value={note} onChange={e => setNote(e.target.value)} /></div>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={record}>Record</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      } />
      <Card className="p-4">
        <Table>
          <TableHeader><TableRow><TableHead>When</TableHead><TableHead>Product</TableHead><TableHead>Type</TableHead><TableHead className="text-right">Qty</TableHead><TableHead>Note</TableHead></TableRow></TableHeader>
          <TableBody>
            {tx.length === 0 && <TableRow><TableCell colSpan={5} className="py-12 text-center text-muted-foreground"><ArrowLeftRight className="mx-auto mb-2 h-8 w-8 opacity-40" />No transactions recorded.</TableCell></TableRow>}
            {(tx as any[]).map(t => (
              <TableRow key={t.id}>
                <TableCell className="text-muted-foreground">{new Date(t.created_at).toLocaleString()}</TableCell>
                <TableCell className="font-medium">{t.products?.name ?? "—"}</TableCell>
                <TableCell><Badge variant={t.type === "stock_out" ? "destructive" : t.type === "stock_in" ? "default" : "secondary"}>{t.type.replace("_", " ")}</Badge></TableCell>
                <TableCell className="text-right font-mono">{t.quantity}</TableCell>
                <TableCell className="text-muted-foreground">{t.note ?? "—"}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
