import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, Search, Download, Package } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { toast } from "sonner";
import { exportPDF, exportExcel } from "@/lib/export";
import { Card } from "@/components/ui/card";

export const Route = createFileRoute("/_app/products")({ component: ProductsPage });

interface Product {
  id: string; name: string; sku: string | null; barcode: string | null;
  description: string | null; category_id: string | null; supplier_id: string | null;
  warehouse_id: string | null; image_url: string | null;
  cost_price: number; selling_price: number; stock_quantity: number;
  low_stock_threshold: number; expiry_date: string | null;
}

const empty: Partial<Product> = { name: "", cost_price: 0, selling_price: 0, stock_quantity: 0, low_stock_threshold: 10 };

function ProductsPage() {
  const { canManage } = useAuth();
  const qc = useQueryClient();
  const [search, setSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<Partial<Product>>(empty);

  const { data: products = [] } = useQuery({
    queryKey: ["products"],
    queryFn: async () => {
      const { data } = await supabase.from("products").select("*").order("created_at", { ascending: false });
      return (data ?? []) as Product[];
    },
  });
  const { data: categories = [] } = useQuery({
    queryKey: ["categories"],
    queryFn: async () => (await supabase.from("categories").select("*").order("name")).data ?? [],
  });
  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers"],
    queryFn: async () => (await supabase.from("suppliers").select("*").order("name")).data ?? [],
  });

  useEffect(() => {
    const ch = supabase.channel("products-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "products" }, () => qc.invalidateQueries({ queryKey: ["products"] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [qc]);

  const filtered = products.filter(p =>
    !search || p.name.toLowerCase().includes(search.toLowerCase()) ||
    p.sku?.toLowerCase().includes(search.toLowerCase()) ||
    p.barcode?.toLowerCase().includes(search.toLowerCase())
  );

  async function handleSave() {
    if (!edit.name) { toast.error("Name required"); return; }
    const payload = {
      name: edit.name,
      sku: edit.sku || null,
      barcode: edit.barcode || null,
      description: edit.description || null,
      category_id: edit.category_id || null,
      supplier_id: edit.supplier_id || null,
      image_url: edit.image_url || null,
      cost_price: Number(edit.cost_price) || 0,
      selling_price: Number(edit.selling_price) || 0,
      stock_quantity: Number(edit.stock_quantity) || 0,
      low_stock_threshold: Number(edit.low_stock_threshold) || 0,
      expiry_date: edit.expiry_date || null,
    };
    const { error } = edit.id
      ? await supabase.from("products").update(payload).eq("id", edit.id)
      : await supabase.from("products").insert(payload);
    if (error) toast.error(error.message);
    else { toast.success(edit.id ? "Product updated" : "Product added"); setOpen(false); setEdit(empty); qc.invalidateQueries({ queryKey: ["products"] }); }
  }

  async function handleDelete(id: string) {
    if (!confirm("Delete this product?")) return;
    const { error } = await supabase.from("products").delete().eq("id", id);
    if (error) toast.error(error.message);
    else { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["products"] }); }
  }

  function startEdit(p?: Product) { setEdit(p ?? empty); setOpen(true); }

  return (
    <div>
      <PageHeader
        title="Products"
        description="Manage your catalog, stock and pricing."
        actions={
          <>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline"><Download className="mr-2 h-4 w-4" />Export</Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent>
                <DropdownMenuItem onClick={() => exportPDF("Products", ["Name", "SKU", "Stock", "Price"], filtered.map(p => [p.name, p.sku ?? "", p.stock_quantity, `$${p.selling_price}`]))}>Export PDF</DropdownMenuItem>
                <DropdownMenuItem onClick={() => exportExcel("Products", filtered.map(p => ({ Name: p.name, SKU: p.sku, Barcode: p.barcode, Stock: p.stock_quantity, Cost: p.cost_price, Price: p.selling_price })))}>Export Excel</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            {canManage && (
              <Dialog open={open} onOpenChange={setOpen}>
                <DialogTrigger asChild><Button onClick={() => startEdit()}><Plus className="mr-2 h-4 w-4" />Add product</Button></DialogTrigger>
                <DialogContent className="max-w-2xl">
                  <DialogHeader><DialogTitle>{edit.id ? "Edit product" : "New product"}</DialogTitle></DialogHeader>
                  <div className="grid gap-4 md:grid-cols-2">
                    <Field label="Name"><Input value={edit.name ?? ""} onChange={e => setEdit({ ...edit, name: e.target.value })} /></Field>
                    <Field label="SKU"><Input value={edit.sku ?? ""} onChange={e => setEdit({ ...edit, sku: e.target.value })} /></Field>
                    <Field label="Barcode"><Input value={edit.barcode ?? ""} onChange={e => setEdit({ ...edit, barcode: e.target.value })} /></Field>
                    <Field label="Image URL"><Input value={edit.image_url ?? ""} onChange={e => setEdit({ ...edit, image_url: e.target.value })} /></Field>
                    <Field label="Category">
                      <Select value={edit.category_id ?? "_none"} onValueChange={v => setEdit({ ...edit, category_id: v === "_none" ? null : v })}>
                        <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="_none">None</SelectItem>
                          {categories.map((c: any) => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </Field>
                    <Field label="Supplier">
                      <Select value={edit.supplier_id ?? "_none"} onValueChange={v => setEdit({ ...edit, supplier_id: v === "_none" ? null : v })}>
                        <SelectTrigger><SelectValue placeholder="None" /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="_none">None</SelectItem>
                          {suppliers.map((s: any) => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </Field>
                    <Field label="Cost price"><Input type="number" step="0.01" value={edit.cost_price ?? 0} onChange={e => setEdit({ ...edit, cost_price: Number(e.target.value) })} /></Field>
                    <Field label="Selling price"><Input type="number" step="0.01" value={edit.selling_price ?? 0} onChange={e => setEdit({ ...edit, selling_price: Number(e.target.value) })} /></Field>
                    <Field label="Stock quantity"><Input type="number" value={edit.stock_quantity ?? 0} onChange={e => setEdit({ ...edit, stock_quantity: Number(e.target.value) })} /></Field>
                    <Field label="Low-stock threshold"><Input type="number" value={edit.low_stock_threshold ?? 10} onChange={e => setEdit({ ...edit, low_stock_threshold: Number(e.target.value) })} /></Field>
                    <Field label="Expiry date"><Input type="date" value={edit.expiry_date ?? ""} onChange={e => setEdit({ ...edit, expiry_date: e.target.value })} /></Field>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                    <Button onClick={handleSave}>{edit.id ? "Save changes" : "Create"}</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            )}
          </>
        }
      />

      <Card className="p-4">
        <div className="mb-3 flex items-center gap-2">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search by name, SKU or barcode…" value={search} onChange={e => setSearch(e.target.value)} className="max-w-md" />
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Product</TableHead>
                <TableHead>SKU</TableHead>
                <TableHead className="text-right">Price</TableHead>
                <TableHead className="text-right">Stock</TableHead>
                <TableHead>Status</TableHead>
                {canManage && <TableHead className="w-24" />}
              </TableRow>
            </TableHeader>
            <TableBody>
              {filtered.length === 0 && (
                <TableRow><TableCell colSpan={6} className="py-12 text-center text-muted-foreground">
                  <Package className="mx-auto mb-2 h-8 w-8 opacity-40" />No products yet.
                </TableCell></TableRow>
              )}
              {filtered.map(p => {
                const low = p.stock_quantity <= p.low_stock_threshold;
                return (
                  <TableRow key={p.id}>
                    <TableCell>
                      <div className="flex items-center gap-3">
                        {p.image_url ? <img src={p.image_url} alt="" className="h-9 w-9 rounded-md object-cover" /> : <div className="grid h-9 w-9 place-items-center rounded-md bg-muted"><Package className="h-4 w-4 text-muted-foreground" /></div>}
                        <div>
                          <p className="font-medium">{p.name}</p>
                          {p.description && <p className="text-xs text-muted-foreground line-clamp-1">{p.description}</p>}
                        </div>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-xs">{p.sku ?? "—"}</TableCell>
                    <TableCell className="text-right">${Number(p.selling_price).toFixed(2)}</TableCell>
                    <TableCell className="text-right font-medium">{p.stock_quantity}</TableCell>
                    <TableCell>{low ? <Badge variant="destructive">Low</Badge> : <Badge variant="secondary">OK</Badge>}</TableCell>
                    {canManage && (
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" aria-label="Edit product" onClick={() => startEdit(p)}><Pencil className="h-4 w-4" /></Button>
                          <Button size="icon" variant="ghost" aria-label="Delete product" onClick={() => handleDelete(p.id)}><Trash2 className="h-4 w-4" /></Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="space-y-2"><Label>{label}</Label>{children}</div>;
}
