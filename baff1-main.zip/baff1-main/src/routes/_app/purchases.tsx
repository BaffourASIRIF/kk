import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Trash2, ClipboardList, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { exportPDF } from "@/lib/export";

export const Route = createFileRoute("/_app/purchases")({ component: PurchasesPage });

interface Line { product_id: string; quantity: number; unit_cost: number; }

function PurchasesPage() {
  const { user, canManage } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [supplierId, setSupplierId] = useState<string>("");
  const [lines, setLines] = useState<Line[]>([{ product_id: "", quantity: 1, unit_cost: 0 }]);

  const { data: purchases = [] } = useQuery({
    queryKey: ["purchases"],
    queryFn: async () => (await supabase.from("purchases").select("*, suppliers(name), purchase_items(*, products(name))").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: products = [] } = useQuery({
    queryKey: ["products-po"],
    queryFn: async () => (await supabase.from("products").select("id,name,cost_price,stock_quantity")).data ?? [],
  });
  const { data: suppliers = [] } = useQuery({
    queryKey: ["suppliers-po"],
    queryFn: async () => (await supabase.from("suppliers").select("id,name").order("name")).data ?? [],
  });

  const total = lines.reduce((a, l) => a + l.quantity * l.unit_cost, 0);

  function setLine(i: number, patch: Partial<Line>) {
    const next = [...lines]; next[i] = { ...next[i], ...patch };
    if (patch.product_id) {
      const p = (products as any[]).find(x => x.id === patch.product_id);
      if (p) next[i].unit_cost = Number(p.cost_price);
    }
    setLines(next);
  }

  async function createPO() {
    const valid = lines.filter(l => l.product_id && l.quantity > 0);
    if (valid.length === 0) { toast.error("Add at least one item"); return; }
    const totalAmount = valid.reduce((a, l) => a + l.quantity * l.unit_cost, 0);
    const { data: po, error } = await supabase.from("purchases").insert({ supplier_id: supplierId || null, total_amount: totalAmount, user_id: user!.id }).select().single();
    if (error || !po) { toast.error(error?.message ?? "Failed"); return; }
    const items = valid.map(l => ({ purchase_id: po.id, product_id: l.product_id, quantity: l.quantity, unit_cost: l.unit_cost, subtotal: l.quantity * l.unit_cost }));
    await supabase.from("purchase_items").insert(items);
    for (const l of valid) {
      const p = (products as any[]).find(x => x.id === l.product_id);
      if (!p) continue;
      const newQty = p.stock_quantity + l.quantity;
      await supabase.from("products").update({ stock_quantity: newQty }).eq("id", l.product_id);
      await supabase.from("inventory_transactions").insert({ product_id: l.product_id, type: "purchase", quantity: l.quantity, reference_id: po.id, user_id: user!.id });
    }
    toast.success(`Purchase ${po.reference_number} received`);
    setOpen(false); setSupplierId(""); setLines([{ product_id: "", quantity: 1, unit_cost: 0 }]);
    qc.invalidateQueries({ queryKey: ["purchases"] });
    qc.invalidateQueries({ queryKey: ["products"] });
    qc.invalidateQueries({ queryKey: ["products-po"] });
  }

  function printPO(p: any) {
    exportPDF(`Purchase ${p.reference_number}`,
      ["Product", "Qty", "Cost", "Subtotal"],
      [
        ...p.purchase_items.map((i: any) => [i.products?.name ?? "—", i.quantity, `$${Number(i.unit_cost).toFixed(2)}`, `$${Number(i.subtotal).toFixed(2)}`]),
        ["", "", "Total", `$${Number(p.total_amount).toFixed(2)}`],
      ]
    );
  }

  return (
    <div>
      <PageHeader title="Purchases" description="Receive goods from suppliers." actions={canManage && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New purchase</Button></DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader><DialogTitle>Record purchase</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2"><Label>Supplier</Label>
                <Select value={supplierId} onValueChange={setSupplierId}>
                  <SelectTrigger><SelectValue placeholder="Select supplier" /></SelectTrigger>
                  <SelectContent>{(suppliers as any[]).map(s => <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>)}</SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Items</Label>
                {lines.map((l, i) => (
                  <div key={i} className="grid grid-cols-12 gap-2">
                    <Select value={l.product_id} onValueChange={v => setLine(i, { product_id: v })}>
                      <SelectTrigger className="col-span-6"><SelectValue placeholder="Select product" /></SelectTrigger>
                      <SelectContent>{(products as any[]).map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent>
                    </Select>
                    <Input className="col-span-2" type="number" value={l.quantity} onChange={e => setLine(i, { quantity: Number(e.target.value) })} placeholder="Qty" />
                    <Input className="col-span-3" type="number" step="0.01" value={l.unit_cost} onChange={e => setLine(i, { unit_cost: Number(e.target.value) })} placeholder="Cost" />
                    <Button variant="ghost" size="icon" className="col-span-1" onClick={() => setLines(lines.filter((_, x) => x !== i))}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => setLines([...lines, { product_id: "", quantity: 1, unit_cost: 0 }])}><Plus className="mr-2 h-4 w-4" />Add line</Button>
              </div>
              <div className="flex justify-end text-lg font-semibold">Total: ${total.toFixed(2)}</div>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={createPO}>Receive</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      )} />
      <Card className="p-4">
        <Table>
          <TableHeader><TableRow><TableHead>Reference</TableHead><TableHead>Supplier</TableHead><TableHead>Date</TableHead><TableHead>Items</TableHead><TableHead className="text-right">Total</TableHead><TableHead className="w-24" /></TableRow></TableHeader>
          <TableBody>
            {purchases.length === 0 && <TableRow><TableCell colSpan={6} className="py-12 text-center text-muted-foreground"><ClipboardList className="mx-auto mb-2 h-8 w-8 opacity-40" />No purchases yet.</TableCell></TableRow>}
            {(purchases as any[]).map(p => (
              <TableRow key={p.id}>
                <TableCell className="font-mono text-xs">{p.reference_number}</TableCell>
                <TableCell>{p.suppliers?.name ?? "—"}</TableCell>
                <TableCell className="text-muted-foreground">{new Date(p.created_at).toLocaleDateString()}</TableCell>
                <TableCell>{p.purchase_items?.length ?? 0}</TableCell>
                <TableCell className="text-right font-semibold">${Number(p.total_amount).toFixed(2)}</TableCell>
                <TableCell><Button size="icon" variant="ghost" onClick={() => printPO(p)}><Download className="h-4 w-4" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
