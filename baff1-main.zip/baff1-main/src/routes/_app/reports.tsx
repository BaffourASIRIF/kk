import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { Download, BarChart3 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { exportPDF, exportExcel } from "@/lib/export";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from "recharts";

export const Route = createFileRoute("/_app/reports")({ component: ReportsPage });

function ReportsPage() {
  const { data } = useQuery({
    queryKey: ["reports"],
    queryFn: async () => {
      const [{ data: products }, { data: sales }, { data: purchases }] = await Promise.all([
        supabase.from("products").select("id,name,stock_quantity,low_stock_threshold,selling_price,cost_price"),
        supabase.from("sales").select("total_amount,created_at"),
        supabase.from("purchases").select("total_amount,created_at"),
      ]);
      return { products: products ?? [], sales: sales ?? [], purchases: purchases ?? [] };
    },
  });

  const products = data?.products ?? [];
  const sales = data?.sales ?? [];
  const purchases = data?.purchases ?? [];
  const lowStock = products.filter(p => p.stock_quantity <= p.low_stock_threshold);
  const revenue = sales.reduce((a, s) => a + Number(s.total_amount), 0);
  const spend = purchases.reduce((a, p) => a + Number(p.total_amount), 0);

  const months = Array.from({ length: 6 }).map((_, i) => {
    const d = new Date(); d.setMonth(d.getMonth() - (5 - i));
    const key = d.toISOString().slice(0, 7);
    return {
      month: d.toLocaleDateString(undefined, { month: "short" }),
      revenue: sales.filter(s => s.created_at.slice(0, 7) === key).reduce((a, s) => a + Number(s.total_amount), 0),
      spend: purchases.filter(p => p.created_at.slice(0, 7) === key).reduce((a, p) => a + Number(p.total_amount), 0),
    };
  });

  return (
    <div>
      <PageHeader title="Reports & Analytics" description="Performance, profitability, and stock health." actions={
        <>
          <Button variant="outline" onClick={() => exportExcel("Inventory_Report", products.map(p => ({ Name: p.name, Stock: p.stock_quantity, Threshold: p.low_stock_threshold, Cost: p.cost_price, Price: p.selling_price })))}><Download className="mr-2 h-4 w-4" />Excel</Button>
          <Button variant="outline" onClick={() => exportPDF("Inventory Report", ["Name", "Stock", "Threshold", "Cost", "Price"], products.map(p => [p.name, p.stock_quantity, p.low_stock_threshold, `$${p.cost_price}`, `$${p.selling_price}`]))}><Download className="mr-2 h-4 w-4" />PDF</Button>
        </>
      } />
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="p-5"><p className="text-sm text-muted-foreground">Total revenue</p><p className="mt-2 font-display text-3xl font-semibold">${revenue.toLocaleString()}</p></Card>
        <Card className="p-5"><p className="text-sm text-muted-foreground">Total spend</p><p className="mt-2 font-display text-3xl font-semibold">${spend.toLocaleString()}</p></Card>
        <Card className="p-5"><p className="text-sm text-muted-foreground">Gross margin</p><p className="mt-2 font-display text-3xl font-semibold text-success">${(revenue - spend).toLocaleString()}</p></Card>
      </div>

      <Card className="mt-6 p-5">
        <div className="mb-4 flex items-center gap-2"><BarChart3 className="h-4 w-4 text-muted-foreground" /><h3 className="font-display text-base font-semibold">Revenue vs spend — 6 months</h3></div>
        <div className="h-72">
          <ResponsiveContainer>
            <BarChart data={months}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="month" stroke="var(--muted-foreground)" fontSize={12} />
              <YAxis stroke="var(--muted-foreground)" fontSize={12} />
              <Tooltip contentStyle={{ background: "var(--card)", border: "1px solid var(--border)", borderRadius: 8 }} />
              <Bar dataKey="revenue" fill="var(--chart-4)" radius={[6, 6, 0, 0]} />
              <Bar dataKey="spend" fill="var(--chart-2)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Card>

      <Card className="mt-6 p-5">
        <h3 className="mb-4 font-display text-base font-semibold">Low-stock items ({lowStock.length})</h3>
        {lowStock.length === 0 ? <p className="text-sm text-muted-foreground">All stock above threshold.</p> : (
          <div className="grid gap-2">
            {lowStock.map(p => (
              <div key={p.id} className="flex items-center justify-between rounded-md border border-border bg-background px-4 py-3">
                <span className="font-medium">{p.name}</span>
                <span className="text-sm text-destructive">{p.stock_quantity} / {p.low_stock_threshold} threshold</span>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
