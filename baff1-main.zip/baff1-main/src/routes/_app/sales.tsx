import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Trash2, ShoppingCart, Download } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";
import { exportPDF } from "@/lib/export";

export const Route = createFileRoute("/_app/sales")({ component: SalesPage });

interface Line { product_id: string; quantity: number; unit_price: number; }

function SalesPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [customer, setCustomer] = useState("");
  const [lines, setLines] = useState<Line[]>([{ product_id: "", quantity: 1, unit_price: 0 }]);

  const { data: sales = [] } = useQuery({
    queryKey: ["sales"],
    queryFn: async () => (await supabase.from("sales").select("*, sale_items(*, products(name))").order("created_at", { ascending: false })).data ?? [],
  });
  const { data: products = [] } = useQuery({
    queryKey: ["products-sale"],
    queryFn: async () => (await supabase.from("products").select("id,name,selling_price,stock_quantity")).data ?? [],
  });

  const total = lines.reduce((a, l) => a + l.quantity * l.unit_price, 0);

  function setLine(i: number, patch: Partial<Line>) {
    const next = [...lines]; next[i] = { ...next[i], ...patch };
    if (patch.product_id) {
      const p = (products as any[]).find(x => x.id === patch.product_id);
      if (p) next[i].unit_price = Number(p.selling_price);
    }
    setLines(next);
  }

  async function createSale() {
    const valid = lines.filter(l => l.product_id && l.quantity > 0);
    if (valid.length === 0) { toast.error("Add at least one item"); return; }
    const totalAmount = valid.reduce((a, l) => a + l.quantity * l.unit_price, 0);
    const { data: sale, error } = await supabase.from("sales").insert({ customer_name: customer || null, total_amount: totalAmount, user_id: user!.id }).select().single();
    if (error || !sale) { toast.error(error?.message ?? "Failed"); return; }
    const items = valid.map(l => ({ sale_id: sale.id, product_id: l.product_id, quantity: l.quantity, unit_price: l.unit_price, subtotal: l.quantity * l.unit_price }));
    const { error: itErr } = await supabase.from("sale_items").insert(items);
    if (itErr) { toast.error(itErr.message); return; }
    // decrement stock + record inventory transactions
    for (const l of valid) {
      const p = (products as any[]).find(x => x.id === l.product_id);
      if (!p) continue;
      const newQty = Math.max(0, p.stock_quantity - l.quantity);
      await supabase.from("products").update({ stock_quantity: newQty }).eq("id", l.product_id);
      await supabase.from("inventory_transactions").insert({ product_id: l.product_id, type: "sale", quantity: l.quantity, reference_id: sale.id, user_id: user!.id });
    }
    toast.success(`Sale ${sale.invoice_number} created`);
    setOpen(false); setCustomer(""); setLines([{ product_id: "", quantity: 1, unit_price: 0 }]);
    qc.invalidateQueries({ queryKey: ["sales"] });
    qc.invalidateQueries({ queryKey: ["products"] });
    qc.invalidateQueries({ queryKey: ["products-sale"] });
  }

  function printInvoice(s: any) {
    exportPDF(`Invoice ${s.invoice_number}`,
      ["Product", "Qty", "Unit", "Subtotal"],
      [
        ...s.sale_items.map((i: any) => [i.products?.name ?? "—", i.quantity, `$${Number(i.unit_price).toFixed(2)}`, `$${Number(i.subtotal).toFixed(2)}`]),
        ["", "", "Total", `$${Number(s.total_amount).toFixed(2)}`],
      ]
    );
  }

  return (
    <div>
      <PageHeader title="Sales" description="Issue invoices and track customer orders." actions={
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button><Plus className="mr-2 h-4 w-4" />New sale</Button></DialogTrigger>
          <DialogContent className="max-w-3xl">
            <DialogHeader><DialogTitle>New sale</DialogTitle></DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2"><Label>Customer name</Label><Input value={customer} onChange={e => setCustomer(e.target.value)} placeholder="Walk-in" /></div>
              <div className="space-y-2">
                <Label>Items</Label>
                {lines.map((l, i) => (
                  <div key={i} className="grid grid-cols-12 gap-2">
                    <Select value={l.product_id} onValueChange={v => setLine(i, { product_id: v })}>
                      <SelectTrigger className="col-span-6"><SelectValue placeholder="Select product" /></SelectTrigger>
                      <SelectContent>{(products as any[]).map(p => <SelectItem key={p.id} value={p.id}>{p.name} ({p.stock_quantity} in stock)</SelectItem>)}</SelectContent>
                    </Select>
                    <Input className="col-span-2" type="number" value={l.quantity} onChange={e => setLine(i, { quantity: Number(e.target.value) })} placeholder="Qty" />
                    <Input className="col-span-3" type="number" step="0.01" value={l.unit_price} onChange={e => setLine(i, { unit_price: Number(e.target.value) })} placeholder="Price" />
                    <Button variant="ghost" size="icon" className="col-span-1" onClick={() => setLines(lines.filter((_, x) => x !== i))}><Trash2 className="h-4 w-4" /></Button>
                  </div>
                ))}
                <Button variant="outline" size="sm" onClick={() => setLines([...lines, { product_id: "", quantity: 1, unit_price: 0 }])}><Plus className="mr-2 h-4 w-4" />Add line</Button>
              </div>
              <div className="flex justify-end text-lg font-semibold">Total: ${total.toFixed(2)}</div>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={createSale}>Create sale</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      } />
      <Card className="p-4">
        <Table>
          <TableHeader><TableRow><TableHead>Invoice</TableHead><TableHead>Customer</TableHead><TableHead>Date</TableHead><TableHead>Items</TableHead><TableHead className="text-right">Total</TableHead><TableHead className="w-24" /></TableRow></TableHeader>
          <TableBody>
            {sales.length === 0 && <TableRow><TableCell colSpan={6} className="py-12 text-center text-muted-foreground"><ShoppingCart className="mx-auto mb-2 h-8 w-8 opacity-40" />No sales yet.</TableCell></TableRow>}
            {(sales as any[]).map(s => (
              <TableRow key={s.id}>
                <TableCell className="font-mono text-xs">{s.invoice_number}</TableCell>
                <TableCell>{s.customer_name ?? "Walk-in"}</TableCell>
                <TableCell className="text-muted-foreground">{new Date(s.created_at).toLocaleDateString()}</TableCell>
                <TableCell>{s.sale_items?.length ?? 0}</TableCell>
                <TableCell className="text-right font-semibold">${Number(s.total_amount).toFixed(2)}</TableCell>
                <TableCell><Button size="icon" variant="ghost" onClick={() => printInvoice(s)}><Download className="h-4 w-4" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}
