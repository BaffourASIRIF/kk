import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth, type AppRole } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/settings")({ component: SettingsPage });

function SettingsPage() {
  const { user, isAdmin } = useAuth();
  const qc = useQueryClient();
  const [fullName, setFullName] = useState("");

  const { data: profile } = useQuery({
    queryKey: ["profile", user?.id],
    enabled: !!user,
    queryFn: async () => (await supabase.from("profiles").select("*").eq("id", user!.id).single()).data,
  });
  useEffect(() => { if (profile) setFullName(profile.full_name ?? ""); }, [profile]);

  const { data: members = [] } = useQuery({
    queryKey: ["members"],
    queryFn: async () => {
      const [{ data: profiles }, { data: roles }] = await Promise.all([
        supabase.from("profiles").select("id,email,full_name"),
        supabase.from("user_roles").select("user_id,role"),
      ]);
      return (profiles ?? []).map(p => ({ ...p, roles: (roles ?? []).filter(r => r.user_id === p.id).map(r => r.role) }));
    },
  });

  async function saveProfile() {
    const { error } = await supabase.from("profiles").update({ full_name: fullName }).eq("id", user!.id);
    if (error) toast.error(error.message); else toast.success("Profile updated");
  }

  async function changeRole(userId: string, role: AppRole) {
    await supabase.from("user_roles").delete().eq("user_id", userId);
    const { error } = await supabase.from("user_roles").insert({ user_id: userId, role });
    if (error) toast.error(error.message);
    else { toast.success("Role updated"); qc.invalidateQueries({ queryKey: ["members"] }); }
  }

  return (
    <div>
      <PageHeader title="Settings" description="Profile and team management." />
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="p-6">
          <h3 className="font-display text-base font-semibold">Your profile</h3>
          <div className="mt-4 space-y-4">
            <div className="space-y-2"><Label>Email</Label><Input value={user?.email ?? ""} disabled /></div>
            <div className="space-y-2"><Label>Full name</Label><Input value={fullName} onChange={e => setFullName(e.target.value)} /></div>
            <Button onClick={saveProfile}>Save profile</Button>
          </div>
        </Card>

        <Card className="p-6">
          <h3 className="font-display text-base font-semibold">Team</h3>
          <p className="mt-1 text-sm text-muted-foreground">{isAdmin ? "Manage roles for everyone." : "Only admins can change roles."}</p>
          <div className="mt-4 overflow-x-auto">
            <Table>
              <TableHeader><TableRow><TableHead>Member</TableHead><TableHead>Role</TableHead></TableRow></TableHeader>
              <TableBody>
                {members.map((m: any) => (
                  <TableRow key={m.id}>
                    <TableCell><p className="font-medium">{m.full_name ?? m.email}</p><p className="text-xs text-muted-foreground">{m.email}</p></TableCell>
                    <TableCell>
                      {isAdmin && m.id !== user?.id ? (
                        <Select value={m.roles[0] ?? "staff"} onValueChange={(v) => changeRole(m.id, v as AppRole)}>
                          <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                          <SelectContent>
                            <SelectItem value="admin">Admin</SelectItem>
                            <SelectItem value="manager">Manager</SelectItem>
                            <SelectItem value="staff">Staff</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <div className="flex gap-1">{m.roles.map((r: string) => <Badge key={r} variant="secondary" className="capitalize">{r}</Badge>)}</div>
                      )}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        </Card>
      </div>
    </div>
  );
}
