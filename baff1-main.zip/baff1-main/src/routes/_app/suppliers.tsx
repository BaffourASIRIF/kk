import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { Plus, Pencil, Trash2, Truck } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { PageHeader } from "@/components/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/suppliers")({ component: SuppliersPage });

function SuppliersPage() {
  const { canManage } = useAuth();
  const qc = useQueryClient();
  const [open, setOpen] = useState(false);
  const [edit, setEdit] = useState<any>({});

  const { data = [] } = useQuery({ queryKey: ["suppliers"], queryFn: async () => (await supabase.from("suppliers").select("*").order("name")).data ?? [] });

  async function save() {
    if (!edit.name) { toast.error("Name required"); return; }
    const payload = { name: edit.name, contact_name: edit.contact_name ?? null, email: edit.email ?? null, phone: edit.phone ?? null, address: edit.address ?? null, notes: edit.notes ?? null };
    const { error } = edit.id ? await supabase.from("suppliers").update(payload).eq("id", edit.id) : await supabase.from("suppliers").insert(payload);
    if (error) toast.error(error.message); else { toast.success("Saved"); setOpen(false); setEdit({}); qc.invalidateQueries({ queryKey: ["suppliers"] }); }
  }
  async function del(id: string) {
    if (!confirm("Delete supplier?")) return;
    const { error } = await supabase.from("suppliers").delete().eq("id", id);
    if (error) toast.error(error.message); else { toast.success("Deleted"); qc.invalidateQueries({ queryKey: ["suppliers"] }); }
  }

  return (
    <div>
      <PageHeader title="Suppliers" description="Vendors and their contact information." actions={canManage && (
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild><Button onClick={() => setEdit({})}><Plus className="mr-2 h-4 w-4" />New supplier</Button></DialogTrigger>
          <DialogContent className="max-w-xl">
            <DialogHeader><DialogTitle>{edit.id ? "Edit" : "New"} supplier</DialogTitle></DialogHeader>
            <div className="grid gap-4 md:grid-cols-2">
              <Fld label="Name"><Input value={edit.name ?? ""} onChange={e => setEdit({ ...edit, name: e.target.value })} /></Fld>
              <Fld label="Contact name"><Input value={edit.contact_name ?? ""} onChange={e => setEdit({ ...edit, contact_name: e.target.value })} /></Fld>
              <Fld label="Email"><Input type="email" value={edit.email ?? ""} onChange={e => setEdit({ ...edit, email: e.target.value })} /></Fld>
              <Fld label="Phone"><Input value={edit.phone ?? ""} onChange={e => setEdit({ ...edit, phone: e.target.value })} /></Fld>
              <Fld label="Address" className="md:col-span-2"><Input value={edit.address ?? ""} onChange={e => setEdit({ ...edit, address: e.target.value })} /></Fld>
              <Fld label="Notes" className="md:col-span-2"><Textarea value={edit.notes ?? ""} onChange={e => setEdit({ ...edit, notes: e.target.value })} /></Fld>
            </div>
            <DialogFooter><Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button><Button onClick={save}>Save</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      )} />
      <Card className="p-4">
        <Table>
          <TableHeader><TableRow><TableHead>Name</TableHead><TableHead>Contact</TableHead><TableHead>Email</TableHead><TableHead>Phone</TableHead>{canManage && <TableHead className="w-24" />}</TableRow></TableHeader>
          <TableBody>
            {data.length === 0 && <TableRow><TableCell colSpan={5} className="py-12 text-center text-muted-foreground"><Truck className="mx-auto mb-2 h-8 w-8 opacity-40" />No suppliers yet.</TableCell></TableRow>}
            {data.map((s: any) => (
              <TableRow key={s.id}>
                <TableCell className="font-medium">{s.name}</TableCell>
                <TableCell>{s.contact_name ?? "—"}</TableCell>
                <TableCell className="text-muted-foreground">{s.email ?? "—"}</TableCell>
                <TableCell className="text-muted-foreground">{s.phone ?? "—"}</TableCell>
                {canManage && <TableCell><div className="flex gap-1"><Button size="icon" variant="ghost" onClick={() => { setEdit(s); setOpen(true); }}><Pencil className="h-4 w-4" /></Button><Button size="icon" variant="ghost" onClick={() => del(s.id)}><Trash2 className="h-4 w-4" /></Button></div></TableCell>}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>
    </div>
  );
}

function Fld({ label, children, className }: { label: string; children: React.ReactNode; className?: string }) {
  return <div className={`space-y-2 ${className ?? ""}`}><Label>{label}</Label>{children}</div>;
}
