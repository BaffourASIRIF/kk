import { createFileRoute, Link, redirect } from "@tanstack/react-router";
import { Boxes, Activity, BarChart3, ShieldCheck, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Stockyard — Real-time Inventory Management" },
      { name: "description", content: "Track products, stock, suppliers, sales and purchases with real-time analytics built for retail, warehouses, and pharmacies." },
      { property: "og:title", content: "Stockyard — Real-time Inventory Management" },
      { property: "og:description", content: "Track products, stock, suppliers, sales and purchases with real-time analytics." },
      { property: "og:url", content: "https://baff1.lovable.app/" },
    ],
    links: [{ rel: "canonical", href: "https://baff1.lovable.app/" }],
    scripts: [
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "Organization",
          name: "Stockyard",
          description: "Modern inventory management for retail, warehouses, and pharmacies.",
          url: "https://baff1.lovable.app/",
        }),
      },
      {
        type: "application/ld+json",
        children: JSON.stringify({
          "@context": "https://schema.org",
          "@type": "WebSite",
          name: "Stockyard",
          url: "https://baff1.lovable.app/",
        }),
      },
    ],
  }),
  component: Landing,
});

function Landing() {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
          <Link to="/" className="flex items-center gap-2">
            <div className="grid h-8 w-8 place-items-center rounded-md bg-primary text-primary-foreground"><Boxes className="h-4 w-4" /></div>
            <span className="font-display text-lg font-semibold tracking-tight">Stockyard</span>
          </Link>
          <div className="flex gap-2">
            <Button variant="ghost" asChild><Link to="/login">Sign in</Link></Button>
            <Button asChild><Link to="/signup">Get started</Link></Button>
          </div>
        </div>
      </header>

      <section className="mx-auto max-w-6xl px-6 py-24">
        <div className="max-w-3xl">
          <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs text-muted-foreground">
            <span className="h-1.5 w-1.5 rounded-full bg-success" /> Real-time inventory
          </span>
          <h1 className="mt-6 font-display text-5xl font-semibold leading-[1.05] tracking-tight md:text-6xl">
            Inventory operations,<br />engineered for the floor.
          </h1>
          <p className="mt-6 max-w-xl text-lg text-muted-foreground">
            Stockyard unifies products, suppliers, sales and purchases into one realtime control room — built for supermarkets, pharmacies, and warehouses.
          </p>
          <div className="mt-8 flex gap-3">
            <Button size="lg" asChild><Link to="/signup">Start free <ArrowRight className="ml-2 h-4 w-4" /></Link></Button>
            <Button size="lg" variant="outline" asChild><Link to="/login">Sign in</Link></Button>
          </div>
        </div>

        <div className="mt-20 grid gap-6 md:grid-cols-3">
          {[
            { icon: Activity, t: "Realtime stock", d: "Every transaction syncs across devices instantly with WebSocket-backed updates." },
            { icon: BarChart3, t: "Analytics built-in", d: "Sales trends, top products, low-stock alerts and exportable PDF/Excel reports." },
            { icon: ShieldCheck, t: "Role-based access", d: "Admins, Managers, and Staff get exactly the access they need — nothing more." },
          ].map((f) => (
            <div key={f.t} className="rounded-xl border border-border bg-card p-6">
              <f.icon className="h-5 w-5 text-muted-foreground" />
              <h2 className="mt-4 font-display text-lg font-semibold">{f.t}</h2>
              <p className="mt-2 text-sm text-muted-foreground">{f.d}</p>
            </div>
          ))}
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto max-w-6xl px-6 py-6 text-sm text-muted-foreground">© {new Date().getFullYear()} Stockyard</div>
      </footer>
    </div>
  );
}

export { redirect };
