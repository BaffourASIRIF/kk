import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, useEffect } from "react";
import { Boxes } from "lucide-react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";

export const Route = createFileRoute("/signup")({
  head: () => ({
    meta: [
      { title: "Create account — Stockyard" },
      { name: "description", content: "Create your Stockyard workspace and start tracking products, suppliers, and sales in minutes." },
      { property: "og:title", content: "Create account — Stockyard" },
      { property: "og:description", content: "Spin up your Stockyard inventory workspace in minutes." },
      { property: "og:url", content: "https://baff1.lovable.app/signup" },
    ],
    links: [{ rel: "canonical", href: "https://baff1.lovable.app/signup" }],
  }),
  component: Signup,
});

const schema = z.object({
  fullName: z.string().trim().min(1).max(100),
  email: z.string().email().max(255),
  password: z.string().min(6).max(72),
});

function Signup() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => { if (user) navigate({ to: "/dashboard", replace: true }); }, [user, navigate]);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const parsed = schema.safeParse({ fullName, email, password });
    if (!parsed.success) { toast.error(parsed.error.issues[0].message); return; }
    setLoading(true);
    const { error } = await supabase.auth.signUp({
      email, password,
      options: { emailRedirectTo: `${window.location.origin}/dashboard`, data: { full_name: fullName } },
    });
    setLoading(false);
    if (error) toast.error(error.message);
    else { toast.success("Account created — check your email to confirm."); navigate({ to: "/login" }); }
  }

  return (
    <div className="grid min-h-screen lg:grid-cols-2">
      <div className="hidden bg-sidebar p-12 text-sidebar-foreground lg:flex lg:flex-col lg:justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="grid h-8 w-8 place-items-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground"><Boxes className="h-4 w-4" /></div>
          <span className="font-display text-lg font-semibold">Stockyard</span>
        </Link>
        <div>
          <h2 className="font-display text-4xl font-semibold leading-tight">Start tracking<br />in minutes.</h2>
          <p className="mt-4 max-w-md text-sidebar-foreground/70">The first account becomes the admin. Add your team afterwards from Settings.</p>
        </div>
        <p className="text-xs text-sidebar-foreground/50">© {new Date().getFullYear()} Stockyard</p>
      </div>
      <div className="flex items-center justify-center p-8">
        <form onSubmit={handleSubmit} className="w-full max-w-sm space-y-5">
          <div>
            <h1 className="font-display text-2xl font-semibold">Create account</h1>
            <p className="mt-1 text-sm text-muted-foreground">Spin up your inventory workspace.</p>
          </div>
          <div className="space-y-2">
            <Label htmlFor="name">Full name</Label>
            <Input id="name" value={fullName} onChange={(e) => setFullName(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="password">Password</Label>
            <Input id="password" type="password" value={password} onChange={(e) => setPassword(e.target.value)} required minLength={6} />
          </div>
          <Button type="submit" className="w-full" disabled={loading}>{loading ? "Creating…" : "Create account"}</Button>
          <p className="text-center text-sm text-muted-foreground">
            Already registered? <Link to="/login" className="font-medium text-foreground hover:underline">Sign in</Link>
          </p>
        </form>
      </div>
    </div>
  );
}
